package vcs.lt.project;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class PlanFormation {


    List<Product> productList = new ArrayList<>();
    List<Macros> macrosList = new ArrayList<>();
    Plan plan = new Plan();


    JSONObject planJson = new JSONObject();
    JSONArray arrayPlan = new JSONArray();

    Database database = new HibernateDatabaseImpl();


//        while (true) {
//        Scanner scanner = new Scanner(System.in);
//
//
//            System.out.println("");
//            System.out.println("Choose operation:");
//            System.out.println("--------------------------------------------------");
//            System.out.println("1 - Display list of products");
//            System.out.println("2 - Add product to your meal");
//            System.out.println("3 - Add meal to your plan");
//            System.out.println("4 - Show your plan");
//
//            int selection = scanner.nextInt();
//
//            switch (selection) {
//
//                case 1:
//                    getProductList();
//                    break;
//                case 2:
//                    addProductToMeal(scanner);
//                    break;
//                case 3:
//                    addMealToPlan();
//                    break;
//                case 4:
//                    printPlan();
//            }
//
//        }

    public List<Product> getProductList() {

        return database.getProducts();
    }

    public List<Product> addProductToMeal(String ingredient, int portionSize) {
//        System.out.println("--------------------------------------------------");
//        System.out.println("Write a product name:");
//        scanner.nextLine();
//
//        String ingredient = scanner.nextLine();
        // nauja
        Product productTemp = database.getProductByName(ingredient);

//        System.out.println("Weight of a product in grams:");
//        double portionSize = scanner.nextDouble();

        double calories = productTemp.getCalories() * portionSize;
        double carbs = productTemp.getCarbs() * portionSize;
        double protein = productTemp.getProtein() * portionSize;
        double fats = productTemp.getFats() * portionSize;
        double fiber = productTemp.getFiber() * portionSize;

        Product productNew = new Product(productTemp.getType(), productTemp.getMeal(), calories, carbs, protein, fats, fiber);

        productList.add(productNew);
        // nauja
        //productList.add(database.getProductByName(ingredient));
//        System.out.println("This is productList: " + productList);
        return productList;
    }

    public void addMealToPlan() {
        Meal meal = new Meal();
        meal.setProducts(productList);
       // System.out.println("This is meal: " + meal);

        // nauja Macros sumavimas
        Macros macros;

        double caloriesTotal = productList.stream().mapToDouble(Product::getCalories).sum();
        double carbsTotal = productList.stream().mapToDouble(Product::getCarbs).sum();
        double proteinTotal = productList.stream().mapToDouble(Product::getProtein).sum();
        double fatTotal = productList.stream().mapToDouble(Product::getFats).sum();
        double fiberTotal = productList.stream().mapToDouble(Product::getFiber).sum();

        macros = new Macros(caloriesTotal, carbsTotal, proteinTotal, fatTotal, fiberTotal);

//        System.out.println("Total: "
//                + "Calories: " + caloriesTotal + " "
//                + "Carbs: " + carbsTotal + " "
//                + "Protein: " + proteinTotal + " "
//                + "Fats: " + fatTotal + " "
//                + "Fiber: " + fiberTotal);

        macrosList.add(macros);
        System.out.println(macrosList);


        // nauja
        // sukuriami product objektai
        JSONArray arrayMeal = new JSONArray();

        for (Product product : productList) {
            JSONObject objProduct = new JSONObject();
            objProduct.put("type", product.getType());
            objProduct.put("meal", product.getMeal());
            objProduct.put("calories", product.getCalories());
            objProduct.put("carbs", product.getCarbs());
            objProduct.put("protein", product.getProtein());
            objProduct.put("fats", product.getFats());
            objProduct.put("fiber", product.getFiber());
            arrayMeal.put(objProduct);

        }
//        planJson.put("Meal", arrayMeal);
        arrayPlan.put(arrayMeal);

        // nauja


        // nauja
        plan.addMeal(meal);
        System.out.println("This is plan: " + plan);
        database.updatePlan(arrayPlan);

        productList.clear();

    }


    public JSONArray getPlan() {
//        System.out.println("This is plan: " + plan);
//        System.out.println("This is macros of the plan: " + macrosList);

        return arrayPlan;
    }
}
