package vcs.lt.project;

public class PlanJSON {

    private String planJson;

    public String getPlanJson() {
        return planJson;
    }

    public void setPlanJson(String planJson) {
        this.planJson = planJson;
    }

    @Override
    public String toString() {
        return planJson;
    }
}
